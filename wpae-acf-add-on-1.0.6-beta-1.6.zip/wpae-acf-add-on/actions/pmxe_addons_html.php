<?php

function pmae_pmxe_addons_html() {
    echo "<input type='hidden' id='pmxe_acf_addon_installed' value='1'>";
}