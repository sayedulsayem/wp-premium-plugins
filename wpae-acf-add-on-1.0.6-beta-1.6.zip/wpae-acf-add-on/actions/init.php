<?php

function pmae_init(){
}

?>