<?php

declare(strict_types=1);

namespace org\wplake\acf_views\pro;

defined('ABSPATH') || exit;

class Acf extends \org\wplake\acf_views\Acf
{
    // nothing to override atm, keep as is for back compatibility
}
