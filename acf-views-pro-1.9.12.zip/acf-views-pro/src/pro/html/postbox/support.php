<?php

$view = $view ?? [];
?>

<p>
    <?php
    echo __("We're here to help you with your questions. Support is handled from our support form.", 'acf-views'); ?>
</p>
<a class="button button-primary button-large" href="https://wplake.org/acf-views-support/"
   target="_blank"><?php
    echo __('Get support', 'acf-views'); ?></a>
