acf.add_action('ready_field/type=relationship', function( $el ){	
	$el.find('.acf-button.button-primary').on('click', function(){
				
        // popup
        popup = acf.newPopup({
            title: $el.attr('title'),
            loading: true,
            width: '300px'
        });
        // ajax
        var ajaxData = {
            action:		'acfef/fields/relationhip/add_post',
            field_key:	field.get('key')
        };
        
        // get HTML
        $.ajax({
            url: acf.get('ajaxurl'),
            data: acf.prepareForAjax(ajaxData),
            type: 'post',
            dataType: 'html',
            success: showForm
        });
    });
    
});

jQuery('.post-slug-field input').on('input', function() {
    var c = this.selectionStart,
        r = /[`~!@#$%^&*()|+=?;:..’“'"<>,€£¥•،٫؟»«\s\{\}\[\]\\\/]+/gi,
        v = jQuery(this).val();
    if(r.test(v)) {
      jQuery(this).val(v.replace(r,'').toLowerCase());
      c--;
    }
    this.setSelectionRange(c, c);
  }); 

jQuery('button.edit-password').on('click', function(){
    jQuery(this).addClass('acfef-hidden').siblings('.pass-strength-result').removeClass('acfef-hidden').parents('.acf-field-password').removeClass('edit_password').addClass('editing_password').next('.acf-field-password').removeClass('edit_password');
    jQuery(this).after('<input type="hidden" name="edit_user_password" value="1"/>');
});
jQuery('body').on('click', 'button.cancel-edit', function(){
    jQuery(this).siblings('button.edit-password').removeClass('acfef-hidden').siblings('.pass-strength-result').addClass('acfef-hidden').parents('.acf-field-password').addClass('edit_password').removeClass('editing_password').next('.acf-field-password').addClass('edit_password');
    jQuery(this).siblings('input[name=edit_user_password]').remove();
});

