<?php 
namespace ACFFrontend\Module;

use Omnipay\Omnipay;
use Omnipay\Common\CreditCard;


if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
 
class ACFEF_Payments_Settings{

    public function acfef_set_credit_card( $payment_card ){
        $current_user = wp_get_current_user();
        $ip_address = $_SERVER['REMOTE_ADDR'];
        if( $ip_address == '::1' ) $ip_address = '8.8.8.8';
        $ip_json = file_get_contents("https://www.iplocate.io/api/lookup/$ip_address");
        $ip_data = json_decode($ip_json, true);

        $full_name = explode( ' ', $payment_card[ 'name' ], 2 );
        $first_name = $full_name[0];
        $last_name = isset($full_name[1]) ? $full_name[1] : '';
        $expire_date = explode( '/', $payment_card[ 'expiry' ] );
        $customer_email = isset( $current_user->user_email ) ? $current_user->user_email : '';
        $billingAddress1 = isset( $payment_card[ 'billingAddress1' ] ) ? $payment_card[ 'billingAddress1' ] : 0;
        $billingAddress2 = isset( $payment_card[ 'billingAddress2' ] ) ? $payment_card[ 'billingAddress2' ] : 0;
        $billingCity = isset( $payment_card[ 'billingCity' ] ) ? $payment_card[ 'billingCity' ] : 0;
        $billingPostcode = isset( $payment_card[ 'billingPostCode' ] ) ? $payment_card[ 'billingPostcode' ] : 0;
        $billingState = isset( $payment_card[ 'billingState' ] ) ? $payment_card[ 'billingState' ] : 0;
        $billingCountry = isset( $payment_card[ 'billingCountry' ] ) ? $payment_card[ 'billingCountry' ] : $ip_data[ 'country_code' ];
        
        try {
            $card = new CreditCard( [
                'name' => $payment_card[ 'name' ],
                'number' => $payment_card[ 'number' ],
                'cvv' => $payment_card[ 'cvv' ],
                'expiryMonth' => $expire_date[0],
                'expiryYear' => $expire_date[1],
                'email' => $customer_email,
                'billingAddress1' => $billingAddress1,
                'billingAddress2' => $billingAddress2,
                'billingCountry' => $billingCountry,
                'billingCity'=> $billingCity,
                'billingPostcode' => $billingPostcode,
                'billingState' => $billingState,
            ] );
            $card->validate();
            
            return $card;
        }
        
        //catch exception
        catch( \Exception $e) {
            return $e->getMessage();
        }      
    }  

    public function acfef_verify_payment(){    
        if( ! isset( $_POST[ 'acfef_pay_to_submit' ] ) ) return;
      
		$current_user_id = get_current_user_id();
		$user_submissions = get_user_meta( $current_user_id, 'acfef_payed_submissions', true );
		$user_submitted = get_user_meta( $current_user_id, 'acfef_payed_submitted', true );
		if( $user_submitted >= $user_submissions ){
            acf_add_validation_error( '', __('Limit Reached. You are no longer authorized to post', 'acf-frontend-form-element') );
        }

    }

    public function acfef_new_payment(){
          // Verify nonce
        if( ! isset( $_POST['acfef_nonce'] ) || ! wp_verify_nonce( $_POST['acfef_nonce'], 'acfef_nonce' ) ) wp_die('Permission denied');

        if( ! isset( $_POST[ 'payment_data' ] ) ) echo 'Something went wrong';

        $data = $_POST[ 'payment_data' ];
        $payment_card = $_POST[ 'payment_card' ];
        $payment_send = [
            'amount' => $_POST[ 'payment_data' ][ 'amount' ],
            'description' => $data[ 'payment_plans' ][0][ 'description' ],
        ];

        if( $data[ 'payment_processor' ] == 'stripe' ){
            $stripe_secret_key = ( get_option( 'acfef_stripe_live_mode' ) ) ? get_option( 'acfef_stripe_live_secret_key' ) : get_option( 'acfef_stripe_test_secret_key' );
            $payment_send[ 'token' ] = $payment_card;
            $payment_send[ 'currency' ] = $data[ 'stripe_currency' ];
            $gateway = Omnipay::create('Stripe');
            if( ! $gateway || ! $stripe_secret_key ){
                wp_send_json_error( 'Could not connect to Stripe. Please check your API keys.' );
            }
            $gateway->setApiKey( $stripe_secret_key );
        }
        if( $data[ 'payment_processor' ] == 'paypal' ){
            $payment_send[ 'card' ] = $this->acfef_set_credit_card( $payment_card );
            $payment_send[ 'currency' ] = $data[ 'paypal_currency' ];
            if( is_string( $payment_send[ 'card' ] ) ){
                wp_send_json_error( $payment_send[ 'card' ] );
            }
            $paypal_client_id = get_option( 'acfef_paypal_client_id' );
            $paypal_secret = get_option( 'acfef_paypal_secret' );  
            $gateway = Omnipay::create('PayPal_Rest');
            if( ! $paypal_client_id || ! $paypal_secret || ! $gateway ){
                wp_send_json_error( 'Could not connect to Paypal. Please check your API keys.' );
            }

            $gateway->initialize(array(
                'clientId' => $paypal_client_id,
                'secret'   => $paypal_secret,
                'testMode' => ! get_option( 'acfef_paypal_live_mode' ), 
            ));
        }

        $response = $gateway->purchase($payment_send)->send();

		$user_id = get_current_user_id();
    
        // Process response
        if ($response->isSuccessful()) {

			global $wpdb;
			$wpdb->insert( 
				$wpdb->prefix . 'acfef_payments', 
				[
					'created_at' => current_time( 'mysql' ),
					'description' => $data[ 'payment_plans' ][0][ 'description' ],
					'external_id' => $response->getTransactionReference(),
					'amount' => $payment_send[ 'amount' ],
					'user' => $user_id,
					'method' => $data[ 'payment_processor' ],
					'currency' => $payment_send[ 'currency' ],
					'product' => $data[ 'payment_plans' ][0][ 'value' ],
				]
			);
           

        $user_submissions = get_user_meta( $user_id, 'acfef_payed_submissions', true );

        $submits = $user_submissions + $data[ 'payment_plans' ][0][ 'value' ];

        update_user_meta( $user_id, 'acfef_payed_submissions', $submits );

        $payment_id = wp_insert_post( $payment_data ); 

        wp_send_json_success( $data[ 'payment_plans' ][0][ 'success_message' ] );

        } else {
            wp_send_json_error( $response->getMessage() );
        }
        
        wp_die();
    }

	public function acfef_add_submission( $post_id, $form ){
        if( ! isset( $form[ 'pay_for_submission' ] ) ) return;

		$active_user_id = get_current_user_id();
		$submitted = get_user_meta( $active_user_id, 'acfef_payed_submitted', true );

		if( ! empty( $submitted ) ){
            $submitted++;
        }else{
            $submitted = 1;
        }

		update_user_meta( $active_user_id, 'acfef_payed_submitted', $submitted );
        update_post_meta( $post_id, 'acfef_payed_post', $active_user_id );

	}
	public function acfef_subtract_submission( $post_id ){
        $paying_user = get_post_meta( $post_id, 'acfef_payed_post', true );

        if( ! $paying_user ) return;
		
		$submitted = get_user_meta( $active_user_id, 'acfef_payed_submitted', true );
		$submitted--;
        update_user_meta( $active_user_id, 'acfef_payed_submitted', $submitted );
        
    }

    public function acfef_payment_settings_fields( $field_keys ){
		$payments_active = array(
			'field' => 'acfef_payments_active',
			'operator' => '==',
			'value' => '1',
		);
		$stripe_active = array(
			'field' => 'acfef_stripe_active',
			'operator' => '==',
			'value' => '1',
		);
		$paypal_active = array(
			'field' => 'acfef_paypal_active',
			'operator' => '==',
			'value' => '1',
		);
		       
        $acfef_local_fields = array(
					array(
						'key' => 'acfef_payments_active',
						'label' => __( 'Activate Payments', 'acf-frontend-form-element' ),
                        'name' => 'acfef_payments_active',
                        'value' => get_option( 'acfef_payments_active' ),
						'type' => 'true_false',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => 0,
						'wrapper' => array(
							'width' => '',
							'class' => '',
							'id' => '',
						),
						'only_front' => 0,
						'message' => '',
						'default_value' => 0,
						'ui' => 1,
						'ui_on_text' => '',
						'ui_off_text' => '',
					),
					array(
						'key' => 'acfef_stripe_tab',
						'label' => __( 'Stripe', 'acf-frontend-form-element' ),
						'type' => 'tab',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
							),
						),
						'wrapper' => array(
							'width' => '',
							'class' => '',
							'id' => '',
						),
						'placement' => 'top',
						'endpoint' => 0,
					),
					array(
						'key' => 'acfef_stripe_active',
						'label' => __( 'Activate Stripe', 'acf-frontend-form-element' ),
						'name' => 'stripe_active',
						'type' => 'true_false',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
							),
						),
						'wrapper' => array(
							'width' => '',
							'class' => '',
							'id' => '',
						),
						'message' => '',
						'default_value' => 0,
						'ui' => 1,
						'ui_on_text' => '',
						'ui_off_text' => '',
					),
					array(
						'key' => 'acfef_stripe_message',
						'type' => 'message',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
								$stripe_active,
							),
						),
						'wrapper' => array(
							'width' => '',
							'class' => '',
							'id' => '',
						),
						'message' => __( '<h2>Set Up</h2>
		
		Click <a target="_blank" href="https://dashboard.stripe.com/register">here</a> to create a Stripe account. Once you do that you will recieve your API Keys.', 'acf-frontend-form-element' ),
						'new_lines' => 'wpautop',
						'esc_html' => 0,
					),
					array(
						'key' => 'acfef_stripe_live_mode',
						'label' => __( 'Use Live Keys', 'acf-frontend-form-element' ),
						'name' => 'live_mode',
						'type' => 'true_false',
						'instructions' => __( 'We reccomend testing out the test keys before using the live keys', 'acf-frontend-form-element' ),
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
								$stripe_active,
							),
						),
						'wrapper' => array(
							'width' => '',
							'class' => '',
							'id' => '',
						),
						'only_front' => 0,
						'message' => '',
						'default_value' => 0,
						'ui' => 1,
						'ui_on_text' => '',
						'ui_off_text' => '',
					),
					array(
						'key' => 'acfef_stripe_live_publish_key',
						'label' => __( 'Live Publishable Key', 'acf-frontend-form-element' ),
						'name' => 'live_publish_key',
						'type' => 'text',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
								$stripe_active,
								array(
									'field' => 'acfef_stripe_live_mode',
									'operator' => '==',
									'value' => '1',
								),
							),
						),
						'wrapper' => array(
							'width' => '50.1',
							'class' => '',
							'id' => '',
						),
					),
					array(
						'key' => 'acfef_stripe_live_secret_key',
						'label' => __( 'Live Secret Key', 'acf-frontend-form-element' ),
						'name' => 'live_secret_key',
						'type' => 'text',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
								$stripe_active,
								array(
									'field' => 'acfef_stripe_live_mode',
									'operator' => '==',
									'value' => '1',
								),
							),
						),
						'wrapper' => array(
							'width' => '50.1',
							'class' => '',
							'id' => '',
						),
					),
					array(
						'key' => 'acfef_stripe_test_publish_key',
						'label' => __( 'Test Publishable Key', 'acf-frontend-form-element' ),
						'name' => 'test_publish_key',
						'type' => 'text',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
								$stripe_active,
								array(
									'field' => 'acfef_stripe_live_mode',
									'operator' => '!=',
									'value' => '1',
								),
							),
						),
						'wrapper' => array(
							'width' => '50.1',
							'class' => '',
							'id' => '',
						),
					),
					array(
						'key' => 'acfef_stripe_test_secret_key',
						'label' => __( 'Test Secret Key', 'acf-frontend-form-element' ),
						'name' => 'test_secret_key',
						'type' => 'text',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
								$stripe_active,
								array(
									'field' => 'acfef_stripe_live_mode',
									'operator' => '!=',
									'value' => '1',
								),
							),
						),
						'wrapper' => array(
							'width' => '50.1',
							'class' => '',
							'id' => '',
						),
					),			
					array(
						'key' => 'acfef_paypal_tab',
						'label' => __( 'Paypal', 'acf-frontend-form-element' ),
						'type' => 'tab',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
							),
						),
						'wrapper' => array(
							'width' => '',
							'class' => '',
							'id' => '',
						),
						'placement' => 'top',
						'endpoint' => 0,
					),
					array(
						'key' => 'acfef_paypal_active',
						'label' => __( 'Activate Paypal', 'acf-frontend-form-element' ),
						'name' => 'paypal_active',
						'type' => 'true_false',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
							),
						),
						'wrapper' => array(
							'width' => '',
							'class' => '',
							'id' => '',
						),
						'message' => '',
						'default_value' => 0,
						'ui' => 1,
						'ui_on_text' => '',
						'ui_off_text' => '',
						'custom_sold_ind' => 0,
					),
					array(
						'key' => 'acfef_paypal_message',
						'type' => 'message',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
								$paypal_active,
							),
						),
						'wrapper' => array(
							'width' => '',
							'class' => '',
							'id' => '',
						),
						'message' => __( '<h2>Set Up</h2>
		
		Click <a target="_blank" href="https://developer.paypal.com/developer/applications/create">here</a> to create a PayPal App. Once you do that you will recieve your API Keys.', 'acf-frontend-form-element' ),
						'new_lines' => 'wpautop',
						'esc_html' => 0,
					),
					array(
						'key' => 'acfef_paypal_live_mode',
						'label' => __( 'Live Mode', 'acf-frontend-form-element' ),
						'name' => 'live_mode',
						'type' => 'true_false',
						'instructions' => __( 'We reccomend testing out the test mode before using switching to live mode', 'acf-frontend-form-element' ),
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
								$paypal_active,
							),
						),
						'wrapper' => array(
							'width' => '',
							'class' => '',
							'id' => '',
						),
						'ui' => 1,
					),
					array(
						'key' => 'acfef_paypal_client_id',
						'label' => __( 'Client ID', 'acf-frontend-form-element' ),
						'name' => 'client_id',
						'type' => 'text',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
								$paypal_active,
							),
						),
						'wrapper' => array(
							'width' => '50.1',
							'class' => '',
							'id' => '',
						),
					),
					array(
						'key' => 'acfef_paypal_secret',
						'label' => __( 'Secret', 'acf-frontend-form-element' ),
						'name' => 'secret',
						'type' => 'text',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => array(
							array(
								$payments_active,
								$paypal_active,
							),
						),
						'wrapper' => array(
							'width' => '50.1',
							'class' => '',
							'id' => '',
						),
					),
				);
            
            foreach( $acfef_local_fields as $local_field ){
                acf_add_local_field( $local_field );
                $field_keys[] = $local_field[ 'key' ];
            }
		return $field_keys;
	}


    public function __construct() {
		add_action( 'wp_ajax_acfef_new_payment', [ $this, 'acfef_new_payment' ] );
        add_action( 'wp_ajax_nopriv_acfef_new_payment', [ $this, 'acfef_new_payment' ] );		add_action( 'acf/validate_save_post', array($this, 'acfef_verify_payment'), 1 );
        add_action( 'acfef/add_post' , [ $this, 'acfef_add_submission' ], 10, 2 );
        add_action( 'delete_post' , [ $this, 'acfef_subtract_submission' ] );
        add_filter( 'acfef/payments_fields', [ $this, 'acfef_payment_settings_fields' ] );

	}
}

