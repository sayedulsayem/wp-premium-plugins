<?php

namespace Omnipay\Common\Http\Exception;

use Omnipay\Common\Http\Exception;

class RequestException extends Exception
{
}
