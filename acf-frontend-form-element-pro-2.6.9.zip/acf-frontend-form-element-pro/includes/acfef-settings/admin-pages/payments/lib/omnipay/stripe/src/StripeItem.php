<?php
/**
 * Stripe Item
 */

namespace Omnipay\Stripe;

use Omnipay\Common\Item;

/**
 * Class StripeItem
 *
 * @package Omnipay\Stripe
 */
class StripeItem extends Item
{

}
