<?php

namespace Omnipay\Common\Exception;

/**
 * Omnipay Exception marker interface
 */
interface OmnipayException
{
}
