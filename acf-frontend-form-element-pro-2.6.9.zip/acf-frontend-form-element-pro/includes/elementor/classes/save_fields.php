<?php
namespace ACFFrontend\Module\Classes;

use ACFFrontend\Plugin;
use ACFFrontend\Module\ACFEF_Module;
use ACFFrontend\Module\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class SaveFields {
	public function iterate_data( $post_id, $data_container ) {
		if ( isset( $data_container['elType'] ) ) {
			if ( ! empty( $data_container['elements'] ) ) {
				$data_container['elements'] = $this->iterate_data( $post_id, $data_container['elements'] );
			}
            if ( empty( $data_container[ 'widgetType' ] ) ) {
                return $data_container;
			}
            return $this->save_widget_fields( $data_container, $post_id, true );
		}

        if( is_array( $data_container ) ){
            foreach ( $data_container as $element_key => $element_value ) {
                $element_data = $this->iterate_data( $post_id, $data_container[ $element_key ] );

                if ( null === $element_data ) {
                    continue;
                }

                $data_container[ $element_key ] = $element_data;
            }
        }

		return $data_container;
	}
	
	public function save_widget_fields( $widget, $post_id = '', $update = false ) {
		$widget_names = [
			'acf_ele_form', 'edit_post', 'edit_term', 'new_term', 'new_post', 'edit_product', 'new_product', 'new_comment', 'edit_user', 'new_user', 'edit_options' 
		];
		if( is_object( $widget ) ){
			if( in_array( $widget->get_name(), $widget_names ) ){
				$settings = $widget->get_settings();
				$wg_id = $widget->get_id();
				$wg_type = $widget->get_name();
			}else{
				return $widget;
			}
		}elseif( is_array( $widget ) ){
			if( in_array( $widget[ 'widgetType' ], $widget_names ) ){
				$settings = $widget[ 'settings' ];
				$wg_id = $widget[ 'id' ];
				$wg_type = $widget[ 'widgetType' ];
			}else{
				return $widget;
			}
		}else{
			return $widget;
		}

		if( ! $post_id ){
			global $post;
			$post_id = $post->ID;
		} 
		$module = ACFEF_Module::instance();
		
	
		if( $wg_type != 'acf_ele_form' ){
			$settings[ 'main_action' ] = $wg_type;
		}else{
			if( ! isset( $settings[ 'main_action' ] ) ){
				$settings[ 'main_action' ] = 'edit_post';
			}
		}
		
		if( ! empty( $settings[ 'fields_selection' ] ) ){
			$exclude = [ 'ACF_field_groups', 'ACF_fields', 'default_fields', 'step', 'message' ];
			switch( $settings[ 'main_action' ] ){
				case 'new_post':
				case 'edit_post':
					$action = $module->get_main_actions( 'post' );
				break;
				case 'new_user':
				case 'edit_user':
					$action = $module->get_main_actions( 'user' );
				break;
				case 'edit_term':
					$action = $module->get_main_actions( 'term' );
				break;
				case 'edit_options':
					$action = $module->get_main_actions( 'options' );
				break;
				case 'new_comment':
					$action = $module->get_main_actions( 'comment' );
				break;
				case 'new_product':
				case 'edit_product':
					$action = $module->get_main_actions( 'product' );
				break;
			}

			if( isset( $action ) ){
				foreach( $settings[ 'fields_selection' ] as $form_field ){
					if( empty( $form_field[ 'field_type' ] ) || in_array( $form_field[ 'field_type' ], $exclude ) ){
						continue;
					}	
					$local_field = [];

					if( $form_field[ 'field_type' ] == 'taxonomy' ){
						$taxonomy = isset( $form_field[ 'field_taxonomy' ] ) ? $form_field[ 'field_taxonomy' ] : 'category';
						$field_key = 'acfef_' . $wg_id .  '_' . $taxonomy;
					}else{
						$field_key = 'acfef_' . $wg_id .  '_' . $form_field[ 'field_type' ];
					}

					$local_field = acf_get_field( $field_key );

					if( ! empty( $local_field ) && ! $update ){
						continue;
					}
					if( empty( $local_field ) ){
						$local_field = [
							'name' => $field_key,
							'key' => $field_key,
						]; 
					}
					if( isset( $form_field[ '__dynamic__' ] ) ) $form_field = $this->acfef_parse_tags( $form_field );
					$default_value = isset( $form_field[ 'field_default_value' ] ) ? $form_field[ 'field_default_value' ] : '';
					if( strpos( $default_value, '[$' ) !== 'false' || strpos( $default_value, '[' ) !== 'false' ){
						$data_default = acfef_get_field_names( $default_value ); 
						$default_value = acfef_get_code_value( $default_value, false, true );
					}  
					if( ! empty( $form_field[ 'default_featured_image' ][ 'id' ] ) ) $default_value = $form_field[ 'default_featured_image' ][ 'id' ];
					$local_field = array_merge( $local_field, [
						'required' => isset( $form_field[ 'field_required' ] ) ? $form_field[ 'field_required' ] : 0,
						'instructions' => isset( $form_field[ 'field_instruction' ] ) ? $form_field[ 'field_instruction' ] : '',
						'wrapper' => [ 'class' => 'elementor-repeater-item-' . $form_field[ '_id' ] ],
						'placeholder' => isset( $form_field[ 'field_placeholder' ] ) ? $form_field[ 'field_placeholder' ] : '',
						'default_value' => $default_value,
						'disabled' => isset( $form_field[ 'field_disabled' ] ) ? $form_field[ 'field_disabled' ] : 0,
						'readonly' => isset( $form_field[ 'field_readonly' ] ) ? $form_field[ 'field_disabled' ] : 0,
					] );
					if( isset( $data_default ) ){
						$local_field[ 'wrapper' ][ 'data-default' ] = $data_default;
						$local_field[ 'wrapper' ][ 'data-dynamic_value' ] = $default_value;
					}
					if( isset( $form_field[ 'field_hidden' ] ) && $form_field[ 'field_hidden' ] ){
						$local_field[ 'wrapper' ][ 'class' ] = 'acf-hidden';
					}
					$field_label = ucwords( str_replace( '_', ' ', $form_field[ 'field_type' ] ) );
					$local_field[ 'label' ] = isset( $form_field[ 'field_label' ] ) ? $form_field[ 'field_label' ] : $field_label;
	
					$form_args = Widgets\ACF_Frontend_Form_Widget::get_post_id( $settings, [], $wg_id, false );
					$edit_id = isset( $form_args[ 'post_id' ] ) ? $form_args[ 'post_id' ] : false;
					$local_field = $action->get_fields_display( $form_field, $local_field, $edit_id, $wg_id );

					if( isset( $local_field[ 'type' ] ) ){ 
						if( $local_field[ 'type' ] == 'password' ){
							$local_field[ 'password_strength' ] = isset( $form_field[ 'password_strength' ] ) ? $form_field[ 'password_strength' ] : 3;
							$password_strength = true;
						}	
					}			
					
					if( isset( $form_field[ 'field_label_on' ] ) ){
						$local_field[ 'label' ] = '';
					}
								
					acf_update_field( $local_field );
				}
	
			}

		}
		return $widget;
    }

	public function acfef_parse_tags( $settings ){
		$dynamic_tags = $settings[ '__dynamic__' ];
		foreach( $dynamic_tags as $control_name => $tag ){
			$tag_value = \Elementor\Plugin::$instance->dynamic_tags->parse_tags_text( $tag, $settings, [ \Elementor\Plugin::$instance->dynamic_tags, 'get_tag_data_content' ] );

			$settings[ $control_name ] = $tag_value;
		}

		return $settings;
	}

	public function __construct(){
		add_action( 'elementor/editor/after_save', [ $this, 'iterate_data' ], 10, 2 );
		add_action( 'elementor/frontend/widget/before_render', [ $this, 'save_widget_fields' ] );
	}
	
}

new SaveFields();