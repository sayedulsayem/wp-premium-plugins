<?php
namespace ACFFrontend\Module\Classes;

use ACFFrontend\Plugin;
use ACFFrontend\Module\ACFEF_Module;
use ACFFrontend\Module\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class FormSubmit {
	public function acfef_after_submit($form, $post_id)
	{
		if( ! isset( $_POST[ '_acf_element_id' ] ) ){
			return;
		}
				
		// fix "prescription" post type creation
		if ( isset( $form['ajax_submit'] ) ) {
			$update_message = $form[ 'update_message' ]; 
			if( strpos( $update_message, '[$' ) !== 'false' || strpos( $update_message, '[' ) !== 'false' ){
				$update_message = acfef_get_code_value( $update_message, $post_id );
			}  
			wp_send_json_success(array(
				'post_id' => $post_id,
				'update_message' => $update_message,
			));
			exit;
		}else{
			// vars
			$return = acf_maybe_get($form, 'return', '');
						
			// redirect
			if( $return ) {

				$object_type = '';
				if( strpos( $post_id, '_' ) !== false ){
					$object = explode( '_', $post_id );
					$object_type = '_' . $object[0][0];
					$post_id = $object[1]; 
				}

				// update %placeholders%
				$return = str_replace('%post_id%', $post_id, $return);
				$return = str_replace('%post_url%', get_permalink($post_id), $return);

				$query_args = [];

				$query_args[ 'updated' ] = $_POST[ '_acf_element_id' ]. '_' . $_POST[ '_acf_screen_id' ];				
				
				if( is_numeric( $post_id ) && $form[ 'redirect_action' ] == 'edit' ){
					$query_args[ 'updated' ] .= '_' . $object_type . $post_id;
				}

				
				if( isset( $_POST[ '_acf_modal' ] ) && $_POST[ '_acf_modal' ] == 1 ) {
					$query_args[ 'modal' ] = true;
				}	
				if( isset( $_POST[ '_acf_element_id' ] ) ) {
					$query_args[ 'form_id' ] = $_POST[ '_acf_element_id' ];
				}
				
				if( isset( $form[ 'redirect_params' ] ) ){
					$query_args = array_merge( $query_args, $form[ 'redirect_params' ] );
				}
			
				$return = add_query_arg( $query_args, $return );

				// redirect
				wp_safe_redirect( $return );
				exit;
				
			}
		}
	}


	public function form_message(){
		$message = '';

		if ( ! isset( $_GET[ 'step' ] ) && isset( $_GET[ 'updated' ] ) && $_GET[ 'updated' ] !== 'true' ){
			$widget = $this->get_the_widget();
			
			if( ! $widget ){
				return;
			}
			$form_id = explode( '_', $_GET[ 'updated' ] );
			$widget_id = $form_id[0];
			$post_id = $widget_page = $form_id[1];
			if( isset( $form_id[2] ) ) $post_id = $form_id[2];
			
			$settings = $widget->get_settings_for_display();

			if( $settings[ 'show_success_message' ] == 'true' ){

				if( isset( $settings[ 'update_message' ] ) ){
					$update_message = $settings[ 'update_message' ]; 
					if( strpos( $update_message, '[$' ) !== 'false' || strpos( $update_message, '[' ) !== 'false' ){
						$update_message = acfef_get_code_value( $update_message, $post_id );
					}  

					$message = '<div id="acfef-message" class="elementor-' . $widget_page . '">
								<div class="elementor-element elementor-element-' . $widget_id . '">
									<div class="acf-notice -success acf-success-message -dismiss"><p class="success-msg">' . $update_message . '</p><a  class="acfef-dismiss close-msg acf-notice-dismiss acf-icon -cancel"></a></div>
								</div>
								</div>';
				}
			}
		}
			
		echo $message;
	}
			
	
	public function pre_save_post( $post_id, $form ){	
		if( ! empty($_POST['acf']['_validate_email']) ) return false;	
			
		return $post_id;
	}		

	public function get_steps( $field ){
		if( $field[ 'field_type' ] == 'step' ){
			return true;
		}
		return false;
	}
	
	public function after_save( $post_id ){					
		
		if( ! isset( $_POST[ '_acf_element_id' ] ) ){
			return $post_id;
		}
		
		$widget = $this->get_the_widget();
		
		$settings = $widget->get_settings_for_display();
		
		$module = ACFEF_Module::instance();
		
		$step = $last_step = false;

		if ( acfef()->is__premium_only() ){
					
			if( isset( $_POST[ '_acf_step_index' ] ) ){
				$step_index = $_POST[ '_acf_step_index' ];
				$steps = array_filter( $settings[ 'fields_selection' ], [ $this, 'get_steps' ] );
				$steps = array_values( $steps );
				$steps = array_merge( $settings[ 'first_step' ], $steps );
				$step = $steps[ $step_index ];
				if( count( $steps ) == $step_index + 1 ){
					$last_step = true;
				}
			}
		
			$email_action = $module->get_submit_actions( 'email' );	
		
		
			if( is_array( $settings[ 'more_actions' ] ) && in_array( 'email', $settings[ 'more_actions' ] ) ){
				$email_action->run( $post_id, $settings, $step );
			}

		}
		
		if( isset( $_POST[ '_acf_step_action' ] ) ){
			$main_action = $_POST[ '_acf_step_action' ];
		}else{
			$main_action = $_POST[ '_acf_main_action' ];
		}
		if( isset( $last_step ) && $last_step == true && $settings[ 'redirect' ] != 'current' ){
			return $post_id;
		}

		if( strpos( $main_action, 'new_' ) !== false ){
			$new_content = true;
		}
		if( $step ) {
			$this->reload_page( $post_id, $settings, [ 'step' => $step, 'last' => $last_step ] );
		}
		
		if( isset( $_POST[ 'log_back_in' ] ) ){
			$user_id = $_POST[ 'log_back_in' ];
			$user_object = get_user_by( 'ID', $user_id );
			if( $user_object ){
				wp_set_current_user( $user_id, $user_object->user_login );
				wp_set_auth_cookie( $user_id );
				do_action( 'wp_login', $user_object->user_login, $user_object ); 
			}
		}

		$wg_id = $_POST[ '_acf_element_id' ];
		
		do_action( 'acfef/on_submit', $post_id, $settings, $wg_id );

		return $post_id;
	}	

	public function reload_page( $post_id, $settings, $step = false ){
		$query_args = [];
		if( isset( $_POST[ '_acf_step_action' ] ) ){
			$step_index = $_POST[ '_acf_step_index' ];
			$main_action = $_POST[ '_acf_step_action' ];
			if( $step[ 'last' ] ){
				$step_index = 1;
				if( $settings[ 'redirect' ] == 'current' ){
					$query_args = [
						'post_id', 'product_id', 'user_id', 'modal', 'form_id', 'step' 
					];
					$redirect_url = remove_query_arg( $query_args );
					wp_safe_redirect( $redirect_url );
					exit();
				}else{
					return $post_id;
				}
			}else{
				$step_index = $step_index + 2;
			}
			$query_args = [
				'step' => $step_index,
			];
		
			if( $main_action == 'new_post' ){
				$query_args[ 'post_id' ] = $post_id;
			}
			if( $main_action == 'new_product' ){
				$query_args[ 'product_id' ] = $post_id;
			}
			if( $main_action == 'new_user' && strpos( $post_id, 'user' ) !== false ){
				$query_args[ 'user_id' ] = explode( '_', $post_id )[1];
			}
			
			if( isset( $_POST[ '_acf_modal' ] ) && $_POST[ '_acf_modal' ] == 1 ) {
				$query_args[ 'modal' ] = true;
			}	
			if( isset( $_POST[ '_acf_element_id' ] ) ) {
				$query_args[ 'form_id' ] = $_POST[ '_acf_element_id' ];
			}
			
			// Redirect user back to the form page, with proper new $_GET parameters.
			$redirect_url = add_query_arg( $query_args, wp_get_referer() );
			wp_safe_redirect( $redirect_url );
			exit();
		}
	}

	public function delete_post(){		
		
		if( ! isset( $_POST[ '_acf_element_id' ] ) ||  ! isset( $_POST[ 'delete_post' ] ) ){
			return;
		}

		$widget = $this->get_the_widget();
		$settings = $widget->get_settings_for_display();

		if( $settings ){
			if( ( isset( $settings[ 'force_delete' ] ) && $settings[ 'force_delete' ] == 'true' ) || ( isset( $settings[ 'force_delete_product' ] ) && $settings[ 'force_delete_product' ] == 'true' ) ){
				$deleted = wp_delete_post( $_POST[ 'delete_post' ], true );
			}else{
				$deleted = wp_trash_post( $_POST[ 'delete_post' ] );
			}

			if( $deleted ){
				wp_safe_redirect( $_POST[ 'redirect_url' ] );
				exit();
			}
		}

	}

	protected function get_the_widget(){
		if( isset( $_POST['_acf_element_id'] ) ){	
			$widget_id = $_POST['_acf_element_id'];
			$post_id = $_POST['_acf_screen_id'];
		}elseif ( isset( $_GET[ 'updated' ] ) ) {
			$form_id = explode( '_', $_GET[ 'updated' ] );
			$widget_id = $form_id[0];
			$post_id = $form_id[1];
		}else{
			return false;
		}
		
		if( isset( $post_id ) ){
			$elementor = Plugin::instance()->elementor();
			
			$document = $elementor->documents->get( $post_id );
			
			$module = ACFEF_Module::instance();
			
			if( $document ){				
				$form = $module->find_element_recursive( $document->get_elements_data(), $widget_id );
			}
			
			if ( ! empty( $form[ 'templateID' ] ) ) {
				$template = $elementor->documents->get( $form['templateID'] );

				if ( $template ) {
					$global_meta = $template->get_elements_data();
					$form = $global_meta[0];
				}
			}
			
			if( ! $form ){
				return false;
			}
			
			$widget = $elementor->elements_manager->create_element_instance( $form );
			
			return $widget;
		}
	}

	public function __construct(){
		add_action( 'acf/submit_form', [ $this, 'acfef_after_submit' ], 10, 2 );
		add_action( 'wp_footer', [ $this, 'form_message' ] );
		add_filter( 'acf/pre_save_post', array( $this, 'pre_save_post' ), 3, 2 );
		add_action( 'acf/save_post' , [ $this, 'after_save' ], 20, 1 );
		add_action( 'wp' , [ $this, 'delete_post' ], 10, 1 );
	}
}

new FormSubmit();