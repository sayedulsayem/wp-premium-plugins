<?php
namespace ACFFrontend\Module\Classes;

use ACFFrontend\Module\ACFEF_Module;
use Elementor\Controls_Manager;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


class MultiStep{

	public function multi_step_settings( $widget ){
		
		$post_type_choices = acfef_get_post_type_choices();    
		
		$widget->add_control(
			'steps_display',
			[
				'label' => __( 'Steps Display', 'acf-frontend-form-element' ),
				'type' => Controls_Manager::SELECT2,
				'label_block' => true,
				'default' => [ 
					'tabs',
				],
				'multiple' => 'true',
				'options' => [
					'tabs' => __( 'Tabs', 'acf-frontend-form-element' ),
					'counter' => __( 'Counter', 'acf-frontend-form-element' ),
				],
								
			]
		);		
		$widget->add_control(
			'responsive_description',
			[
				'raw' => __( 'Responsive visibility will take effect only on preview or live page, and not while editing in Elementor.', 'elementor' ),
				'type' => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-descriptor',
			]
		);
		$widget->add_control(
			'steps_tabs_display',
			[
				'label' => __( 'Step Tabs Display', 'acf-frontend-form-element' ),
				'type' => Controls_Manager::SELECT2,
				'label_block' => 'true',				
				'default' => [
					'desktop', 'tablet'
				],
				'multiple' => 'true',
				'options' => [
					'desktop' => __( 'Desktop', 'acf-frontend-form-element' ),
					'tablet' => __( 'Tablet', 'acf-frontend-form-element' ),
					'phone' => __( 'Mobile', 'acf-frontend-form-element' ),
				],
				'condition' => [
					'steps_display' => 'tabs'	
				],				
			]
		);		
		$widget->add_control(
			'tabs_align',
			[
				'label' => __( 'Tabs Position', 'elementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'horizontal',
				'options' => [
					'horizontal' => __( 'Top', 'elementor' ),
					'vertical' => __( 'Side', 'elementor' ),
				],
				'prefix_class' => 'elementor-tabs-view-',
				'condition' => [
					'steps_display' => 'tabs'	
				],						
			]
		);
		
		$widget->add_control(
			'steps_counter_display',
			[
				'label' => __( 'Step Counter Display', 'acf-frontend-form-element' ),
				'type' => Controls_Manager::SELECT2,
				'label_block' => 'true',
				'default' => [
					'desktop', 'tablet', 'phone',
				],
				'multiple' => 'true',
				'options' => [
					'desktop' => __( 'Desktop', 'acf-frontend-form-element' ),
					'tablet' => __( 'Tablet', 'acf-frontend-form-element' ),
					'phone' => __( 'Mobile', 'acf-frontend-form-element' ),
				],
				'condition' => [
					'steps_display' => 'counter'	
				],				
			]
		);		
		$widget->add_control(
			'counter_prefix',
			[
				'label' => __( 'Counter Prefix', 'acf-frontend-form-element' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Step ', 'acf-frontend-form-element' ),
				'default' => __( 'Step ', 'acf-frontend-form-element' ),
				'dynamic' => [
					'active' => true,
				],	
				'condition' => [
					'steps_display' => 'counter'	
				],							
			]
		);			
		$widget->add_control(
			'counter_suffix',
			[
				'label' => __( 'Counter Suffix', 'acf-frontend-form-element' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],	
				'condition' => [
					'steps_display' => 'counter'	
				],							
			]
		);	
		
		$widget->add_control(
			'step_number',
			[
				'label' => __( 'Step Number in Tabs', 'acf-frontend-form-element' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'show', 'acf-frontend-form-element' ),
				'label_off' => __( 'hide','acf-frontend-form-element' ),
				'return_value' => 'true',
				'condition' => [
					'steps_display' => 'tabs'	
				],
			]
		);	
		
		$widget->add_control(
			'tab_links',
			[
				'label' => __( 'Link to Step in Tabs', 'acf-frontend-form-element' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'acf-frontend-form-element' ),
				'label_off' => __( 'No','acf-frontend-form-element' ),
				'return_value' => 'true',
				'condition' => [
					'steps_display' => 'tabs',	
				],
			]
		);	
	

	}

	public function multi_form_render( $settings, $form_args, $widget ){
		$wg_id = $widget->get_id();

		$editor = \Elementor\Plugin::$instance->editor->is_edit_mode();
		$current_post = get_post();
		$active_user = wp_get_current_user();
		$tabs_display = $settings[ 'steps_tabs_display' ];
		$counter_display = $settings[ 'steps_counter_display' ];
		$screens = [
					'desktop' => __( 'Desktop', 'acf-frontend-form-element' ),
					'tablet' => __( 'Tablet', 'acf-frontend-form-element' ),
					'phone' => __( 'Mobile', 'acf-frontend-form-element' ),
					];
		$is_step = isset( $_GET[ 'step' ] );
		$id_int = substr( $widget->get_id_int(), 0, 3 );

		
		global $wp;
		$current_url = home_url( $wp->request );
		$query_args = $_GET;
		$full_link = add_query_arg( $query_args, $current_url );
		
		if( $settings[ 'show_in_modal' ] ){
			$query_args[ 'modal' ] = $wg_id;
		}
	
		if( isset( $_GET[ 'post_id' ] ) ){
			$query_args[ 'modal' ] = $_GET[ 'post_id' ];
		}
		
		$tabs_responsive = '';	
		if( $tabs_display ){
			foreach( $screens as $screen => $label ){
				if( ! in_array( $screen, $tabs_display ) ){
					$tabs_responsive .= 'elementor-hidden-' . $screen . ' ';
				}
			}
		}
		
		$counter_responsive = '';
		if( $counter_display ){
			foreach( $screens as $screen => $label ){
				if( ! in_array( $screen, $counter_display ) ){
					$counter_responsive .= 'elementor-hidden-' . $screen . ' ';
				}
			}
		}

		$total_steps = count( $form_args[ 'fields' ][ 'steps' ] );
		
		echo '<div class="elementor-tabs ' . $tabs_responsive . '"><div class="acfef-tabs-wrapper">';
		$steps = $form_args[ 'fields' ][ 'steps' ];

		foreach( $steps as $index => $form_step ){
			$active = $step_num = $step_link = '';
			$index--;
			$step_count = $index+1;
			
			if( in_array( 'tabs', $settings[ 'steps_display' ] ) ){
				if( ( $is_step && $_GET[ 'step' ] - 1 == $index ) || ( $index == 0 && ! $is_step ) ){
					$active = 'active';
				}

				if( $settings[ 'tab_links' ] && $active == '' ){
					$query_args[ 'step' ] = $step_count;
					$step_link = 'href="' . add_query_arg( $query_args, $current_url ) . '"';
				}
					
				$change_tabs = '';
				if( $editor ){
					$change_tabs = ' onclick="changeTab(' . $step_count . ')"';
				}
					
				$step_title = ( $form_step[ 'form_title' ] ) ? $form_step[ 'form_title' ] : $settings[ 'form_title' ];
				if( $form_step[ 'step_tab_text' ] ){
					$step_title = $form_step[ 'step_tab_text' ];
				}
				if( ! isset( $step_title ) || $step_title == '' ){
					$step_title = __( 'Step', 'acf-frontend-form-element' ) . ' ' . $step_count;
				}else{
					if( $settings[ 'step_number' ] ){
						$step_title = $step_count . '. ' . $step_title;
					}
				}

				echo '<a id="elementor-tab-title-' .$wg_id . $id_int . $step_count . '" class="form-tab ' . $active . ' step-' . $step_count . '" ' . $step_link . $change_tabs . '><p class="step-name">' . $step_title . '</p></a>';
			}
			
		}
		echo '</div>';
		
		echo '<div class="form-steps elementor-tabs-content-wrapper">';

		$field_keys = [];

		foreach( $steps as $index => $form_step ){
			$step_count = $index;
			$index--;
			$display = true;
			$previous_fields = $defaults = $field_groups = $post_id = $new_post = $show_title = $show_content = $can_edit = false;
			$fields = [];
			$active_user = wp_get_current_user();		
			
			if( isset( $form_step[ 'overwrite_settings' ] ) && $form_step[ 'overwrite_settings' ] == 'true' ){
				$action_settings = $form_step;
			}else{
				$action_settings = $settings;
			}

			$step_action = $action_settings[ 'main_action' ];
			if( 'continue' == $step_action ){
				if( $index == 0 ){
					$step_action = $settings[ 'main_action' ];
				}else{
					$counter = $index;
					while( $counter > 0 && $step_action == 'continue' ) {
						$step_action = $settings[ 'fields_selection' ][ $counter-1 ][ 'main_action' ];
						$counter--;
					}
				}
			}

			$fields = $form_step[ 'fields' ];

			$defaults = apply_filters( 'acfef/default_step_fields', $defaults, $form_step, $wg_id . '_' . $step_count );
			
			$prev_button = $multi_buttons = '';

			
			if( $index > 0 ){  
				if($form_step[ 'prev_button_text' ] ){
					$query_args[ 'step' ] = $index;
					$prev_button = '<input type="hidden" name="prev_step_link" value="' . add_query_arg( $query_args, $current_url ) . '"/>';
					$prev_button .= '<input type="submit" name="prev_step" class="acfef-prev-button acfef-submit-button acf-button button button-primary" value="' . $form_step[ 'prev_button_text' ] . '"/> ';
					$multi_buttons = 'acfef-multi-buttons-align';
				}
			}
			
			$next_button = '<input type="submit" class="acfef-submit-button acf-button button button-primary" value="' . $form_step[ 'next_button_text' ] . '" />';
			
			$submit_button =  '<div class="acf-form-submit"><div class="acfef-submit-buttons ' . $multi_buttons . '">' . $prev_button . $next_button . '<span class="acf-spinner"></span></div></div>';

			$hidden_fields = array_merge( $form_args[ 'hidden_fields' ], [
				'step_index' => $index,
				'step_action' => $step_action,
				'modal' => 1,
			] );
			
			if( isset( $action_settings[ 'save_progress_button' ] ) && $action_settings[ 'save_progress_button' ] && in_array( $action_settings[ 'new_post_status' ], [ 'publish', 'pending' ] ) ){
				$submit_button .= '<br><div class="acfef-draft-buttons">';
				if( $action_settings[ 'saved_draft_desc' ] ){
					$submit_button .= '<p class="description"><span class="btn-dsc">' . $action_settings[ 'saved_draft_desc' ] . '</span></p>';
				}
				$submit_button .= '<input formnovalidate type="submit" class="acfef-draft-button acf-button button button-secondary" value="' . $action_settings[ 'saved_draft_text' ] . '" name="acfef_save_draft" /></div>';
			} 

			if( ! $fields ){
				$fields = $field_groups = [ 'none' ];
			}


			$step_form_args = array_merge( $form_args, array( 'fields' => $fields, 'submit_value' => '', 'html_submit_button' => $submit_button, 'hidden_fields' => $hidden_fields  ) );


			$post_status = 'publish';
			if( $step_action == 'edit_post' || $step_action == 'new_post' ){
				if( $form_step[ 'new_post_status' ] ){
					$post_status = $form_step[ 'new_post_status' ];
				}
			}
			if( isset( $form_step[ 'overwrite_settings' ] ) && $form_step[ 'overwrite_settings' ] == 'true' ){
				$step_form_args[ 'post_status' ] = $post_status;
			}
			$step_form_args = $widget->get_post_id( $action_settings, $step_form_args, $wg_id, true, true );

			$step_form_args = apply_filters( 'acfef/step_form_args', $step_form_args, $action_settings );

			if( $index > 0 && ! $form_step[ 'overwrite_settings' ] ){
				if( ! empty( $field_keys ) ){
					ob_start();
	
					$field_arrays = [];
					foreach( $field_keys as $content_id => $previous_fields ){
						$previous_fields = array_diff( $previous_fields, [ 'acfef_' . $wg_id . '_password', 'acfef_' . $wg_id . '_confirm_password' ] );
						foreach( $previous_fields as $field ){
							$field_data = acf_maybe_get_field( $field, $content_id, false );
							$field_data[ 'wrapper' ][ 'class' ] .= ' acfef-hidden';
							$field_data[ 'required' ] = 0;
							$field_arrays[] = $field_data;
						}
						acf_render_fields( $field_arrays, $content_id );
					}
					
					$step_form_args[ 'html_after_fields' ] .= ob_get_contents();
					ob_end_clean();
				}
			}
			foreach( $fields as $field_key ){
				$field_keys[ $step_form_args[ 'post_id' ] ][ $field_key ] = $field_key;
			}

			if( ( $is_step && $_GET[ 'step' ] - 1 == $index ) || ( $index == 0 && ! $is_step ) || ( $editor ) ){
				if( $form_step[ 'overwrite_permissions_settings' ] ) $display = $widget->show_widget( $wg_id, $form_step, $step_form_args );
				$step_active = '';
				if( $editor ){ 
				if( $index == 0 ){
						$step_active = ' active';
					}else{
						$step_active = ' step-hidden';
					}
				}
				echo '<div class="multi-step step-' . $step_count . $step_active . '">';
				if( $display ){
				
					if( in_array( 'counter', $settings[ 'steps_display' ] ) ){
						echo '<p class="' . $counter_responsive . 'step-count">' . $settings[ 'counter_prefix' ] .  $step_count . '/' . $total_steps . $settings[ 'counter_suffix' ] . '</p>';
					}	

					$step_title = ( $form_step[ 'form_title' ] ) ? $form_step[ 'form_title' ] : $settings[ 'form_title' ];
					
					if( isset( $step_title ) ){
						echo '<h2 class="acfef-form-title">' . $step_title . '</h2>';
					}  
					if( $fields == [ 'none' ] && $editor ){
						echo '<div class="acf-notice -error acf-error-message -dismiss"><p>' . __( 'Please add some fields to this step.', 'acf-frontend-form-element' ) . '</p></div>';
					}
					acfef_render_form( $step_form_args );
					if( isset( $action_settings[ 'saved_drafts' ] ) && $action_settings[ 'saved_drafts' ] && $step_action == 'new_post' ){
						$action_settings[ 'show_in_modal' ] = $settings[ 'show_in_modal' ];
						echo $widget->saved_drafts( $wg_id, $action_settings );
					}
					
					echo '</div>';
				}else{
					switch( $form_step[ 'not_allowed' ] ){
						case 'show_message':
							echo '<div class="acf-notice -error acf-error-message"><p>' . $form_step[ 'not_allowed_message' ] . '</p></div>';
						break;
						case 'custom_content': 
							echo '<div class="not_allowed_message">' . $form_step[ 'not_allowed_content' ] . '</div>';
						break;	
					}			
				}
				echo '</div>';
			}
		}
		echo '</div></div>';
	
	}


	public function __construct() {
		add_action( 'acfef/multi_step_settings', [ $this, 'multi_step_settings' ] );
		add_action( 'acfef/multi_form_render', [ $this, 'multi_form_render' ], 10, 3 );
	}

}

new MultiStep();
