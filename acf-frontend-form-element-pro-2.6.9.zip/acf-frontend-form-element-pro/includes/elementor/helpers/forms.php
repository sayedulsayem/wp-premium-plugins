<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


function acfef_render_form( $args = array() ) {
		
    // Vars.
    $fields = array();
    
    // Extract vars.
    $post_id = $args['post_id'];
    
    $uploader = isset( $args['uploader'] ) ? $args['uploader'] : 'wp';
    // Set uploader type.
    acf_update_setting('uploader', $uploader);
    
    foreach( $args['fields'] as $selector ) {
        $fields[] = acf_maybe_get_field( $selector, $post_id, false );
    }


    acf_add_local_field( array(
        'prefix'	=> 'acf',
        'name'		=> '_validate_email',
        'key'		=> '_validate_email',
        'label'		=> __('Validate Email', 'acf'),
        'type'		=> 'text',
        'value'		=> '',
        'wrapper'	=> array('style' => 'display:none !important;')
    ) );
    $fields[] = acf_get_field('_validate_email');
    
    
    // Display updated_message
/* 	if( !empty($_GET['updated']) && $args['updated_message'] ) {
        printf( $args['html_updated_message'], $args['updated_message'] );
    } */
    $args['form_attributes'] = wp_parse_args( $args['form_attributes'], array(
        'id'					=> $args['id'],
        'class'					=> 'acf-form',
        'action'				=> '',
        'method'				=> 'post',
    ));
    ?>
    <form <?php echo acf_esc_attrs( $args['form_attributes'] ) ?>> 
    <?php
        acf_form_data( array_merge( array( 
            'screen'	=> 'acf_form',
            'post_id'	=> $args['post_id'],
            'form'		=> acf_encrypt(json_encode( $args ))
        ), $args[ 'hidden_fields' ] ) );
    ?>
    <div class="acf-fields acf-form-fields -<?php echo esc_attr($args['label_placement'])?>">
        <?php acf_render_fields( $fields, $post_id, $args['field_el'], $args['instruction_placement'] ); ?>
        <?php echo $args['html_after_fields']; ?>
    </div>
        <div class="acf-form-submit">
            <?php printf( $args['html_submit_button'], $args['submit_value'] ) ?>
        </div>
    </form>
    <?php
}