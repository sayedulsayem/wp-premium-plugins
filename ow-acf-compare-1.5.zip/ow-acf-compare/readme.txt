=== Oasis Workflow ACF Compare Add On ===
Contributors: nuggetsol
Tags: workflow, work flow, advanced custom fields, compare, revision compare
Requires at least: 3.9
Tested up to: 5.2.3
Stable tag: 1.5

Compare Advanced Custom Fields between the original and revised article.

== Description ==


== Installation ==
1. Download the plugin zip file to your desktop
2. Upload the plugin to WordPress
3. Activate your license by going to Workflows --> Settings --> License

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.5 =
 * Added support to compare ACF Component Fields.

= 1.4 =
 * Fixed loading of language translation files.
 * Fixed comparison of choice field type.

= 1.3 =
* Fixed: Field comparison if field values are added during post revision.
* Fixed: Field comparison for Flexible and Repeater fields.
* Added support to compare ACF Group fields.

= 1.2 =
* Added support to compare ACF Flexible fields.
* Enhanced the comparison UI to look and behave similar to the OOTB revision compare.

= 1.1 =
* Added support for comparing ACF jQuery fields like Datepicker, Date/Time picker, Time picker and Color picker.
* Added support for comparing WYSIWYG editor contents.

= 1.0 =
* Initial version
* Compare ACF fields between the original and revision article. 
* Supports most of the ACF fields including Repeater field.